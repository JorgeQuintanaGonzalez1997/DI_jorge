﻿// MainPage.xaml.cs
using Firebase.Database;
using Firebase.Database.Query;
using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Maui.Controls;

namespace UD02FirebaseJorge
{
    public partial class MainPage : ContentPage
    {
        private readonly FirebaseClient _firebaseClient;
        public ObservableCollection<Tasca> Tasques { get; set; }

        public MainPage()
        {

            /*http://fir-jorge-cac-73-default-rtdb.europe-west1.firebasedatabase.app 
             * */
            InitializeComponent();
            _firebaseClient = new FirebaseClient("https://fir-jorge-cac73-default-rtdb.europe-west1.firebasedatabase.app"); // Reemplaza con tu URL de Firebase
            Tasques = new ObservableCollection<Tasca>();
            BindingContext = this;
            LoadTasks();
        }

        private async Task<int> GetNextId()
        {
            try
            {
                var tasks = await _firebaseClient.Child("Tasques").OnceAsync<Tasca>();
                return tasks.Any() ? tasks.Max(t => t.Object.Id) + 1 : 1;
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", $"Error obteniendo el próximo ID: {ex.Message}", "OK");
                return 1;
            }
        }

        private async void LoadTasks()
        {
            try
            {
                var firebaseTasks = await _firebaseClient.Child("Tasques").OnceAsync<Tasca>();
                Tasques.Clear();

                foreach (var task in firebaseTasks)
                {
                    Tasques.Add(task.Object);
                }
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", $"Error cargando las tareas: {ex.Message}", "OK");
            }
        }

        private async void AddTaskButton_Clicked(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(NewTaskEntry.Text))
                {
                    var newTask = new Tasca(await GetNextId(), NewTaskEntry.Text);
                    await _firebaseClient.Child("Tasques").PostAsync(newTask);
                    Tasques.Add(newTask);
                    NewTaskEntry.Text = string.Empty;
                }
                else
                {
                    await DisplayAlert("Advertencia", "El campo de tarea no puede estar vacío.", "OK");
                }
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", $"Error añadiendo la tarea: {ex.Message}", "OK");
            }
        }

        private async void DeleteTaskButton_Clicked(object sender, EventArgs e)
        {
            try
            {
                if (TaskListView.SelectedItem is Tasca selectedTask)
                {
                    var firebaseTask = (await _firebaseClient.Child("Tasques").OnceAsync<Tasca>())
                        .FirstOrDefault(t => t.Object.Id == selectedTask.Id);

                    if (firebaseTask != null)
                    {
                        await _firebaseClient.Child("Tasques").Child(firebaseTask.Key).DeleteAsync();
                        Tasques.Remove(selectedTask);
                    }
                    else
                    {
                        await DisplayAlert("Advertencia", "No se pudo encontrar la tarea seleccionada en la base de datos.", "OK");
                    }
                }
                else
                {
                    await DisplayAlert("Advertencia", "Por favor selecciona una tarea para eliminar.", "OK");
                }
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", $"Error eliminando la tarea: {ex.Message}", "OK");
            }
        }

        private void SelectTaskButton_Clicked(object sender, EventArgs e)
        {
            try
            {
                if (TaskListView.SelectedItem is Tasca selectedTask)
                {
                    DisplayAlert("Tasca Seleccionada", $"ID: {selectedTask.Id}\nNombre: {selectedTask.Nombre}", "OK");
                }
                else
                {
                    DisplayAlert("Advertencia", "Por favor selecciona una tarea para ver.", "OK");
                }
            }
            catch (Exception ex)
            {
                DisplayAlert("Error", $"Error seleccionando la tarea: {ex.Message}", "OK");
            }
        }
    }

}