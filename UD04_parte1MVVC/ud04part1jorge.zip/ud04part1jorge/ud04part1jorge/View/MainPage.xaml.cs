﻿namespace ud04part1jorge.View;

public partial class MainPage : ContentPage
{
    

    public MainPage()
    {
        InitializeComponent();
    }
    


}
