using System.Collections.ObjectModel;

namespace ud04part1jorge.View;

public partial class AddItemNewWindow : ContentPage
{
    
        public AddItemNewWindow()
        {
            InitializeComponent();
        }
    
    /*private ObservableCollection<string> _items;

    public ObservableCollection<string> Items
    {
        get => _items;
        set
        {
            _items = value;
            OnPropertyChanged(); // Notifica cambios para actualizar el Binding
        }
    }
    */

    

    // Este m�todo se llama al recibir el par�metro "pItems" al navegar a esta p�gina.
    /*protected override async void OnNavigatedTo()
    {
        base.OnNavigatedTo();
        if (Items != null)
        {
            // L�gica para manejar los datos recibidos
            await DisplayAlert("Recibido", $"Se recibieron {Items.Count} elementos", "OK");
        }
    }*/
}