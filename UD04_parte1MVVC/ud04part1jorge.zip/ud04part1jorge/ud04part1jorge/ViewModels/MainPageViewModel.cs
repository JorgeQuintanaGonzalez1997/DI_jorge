﻿using Newtonsoft.Json;
using System.Collections.ObjectModel;
using System.Windows.Input;
using ud04part1jorge.Models;

namespace ud04part1jorge.ViewModels
{
    public class MainPageViewModel : BaseViewModel
    {
        public ObservableCollection<TodoItem> Items { get; set; }
        public ICommand AddItemCommandNewWindow { get; }
        public ICommand DeleteItemCommand { get; }
        public MainPageViewModel()
        {
            Items = new ObservableCollection<TodoItem>
            {
                new TodoItem { Title = "Tarea 1", IsCompleted = false },
                new TodoItem { Title = "Tarea 2", IsCompleted = true }
            };
            AddItemCommandNewWindow = new Command(async () =>
            {
                string serializedItems = JsonConvert.SerializeObject(Items);
                await Shell.Current.GoToAsync($"///AddItemNewWindow?pItems={Uri.EscapeDataString(serializedItems)}");
            });
            DeleteItemCommand = new Command<TodoItem>(item =>
            {
                if (Items.Contains(item))
                    Items.Remove(item);
            });
        }
        public void AddNewItem(TodoItem newItem)
        {
            Items.Add(newItem);
        }
    }
}