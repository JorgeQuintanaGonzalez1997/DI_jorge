﻿using Newtonsoft.Json;
using System.Collections.ObjectModel;
using System.Windows.Input;
using ud04part1jorge.Models;

namespace ud04part1jorge.ViewModels
{
    [QueryProperty(nameof(SerializedItems), "pItems")]
    public class AddItemNewWindowViewModel : BaseViewModel
    {
        private string newTaskTitle;
        public string NewTaskTitle
        {
            get => newTaskTitle;
            set => SetProperty(ref newTaskTitle, value);
        }
        private bool newTaskIsCompleted;
        public bool NewTaskIsCompleted
        {
            get => newTaskIsCompleted;
            set => SetProperty(ref newTaskIsCompleted, value);
        }
        private string serializedItems;
        public string SerializedItems
        {
            get => serializedItems;
            set
            {
                serializedItems = value;

                if (!string.IsNullOrEmpty(serializedItems))
                {
                    Items = JsonConvert.DeserializeObject<ObservableCollection<TodoItem>>(serializedItems);
                }
            }
        }
        public ObservableCollection<TodoItem> Items { get; set; } = new ObservableCollection<TodoItem>();
        public ICommand AddTaskCommand { get; }
        public ICommand CancelCommand { get; }
        public AddItemNewWindowViewModel()
        {
            AddTaskCommand = new Command(async () =>
            {
                var newTask = new TodoItem
                {
                    Title = NewTaskTitle,
                    IsCompleted = NewTaskIsCompleted
                };
                var mainPageViewModel = DependencyService.Get<MainPageViewModel>();
                mainPageViewModel.AddNewItem(newTask);
                await Shell.Current.GoToAsync("///MainPage");
            });

            CancelCommand = new Command(async () =>
            {
                await Shell.Current.GoToAsync("..");
            });
        }
    }
}
