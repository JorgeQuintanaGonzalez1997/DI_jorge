﻿using Microsoft.Extensions.Logging;
using ud04part1jorge.ViewModels;

namespace ud04part1jorge
{
    public static class MauiProgram
    {
        public static MauiApp CreateMauiApp()
        {
            var builder = MauiApp.CreateBuilder();
            builder
                .UseMauiApp<App>()
                .ConfigureFonts(fonts =>
                {
                    fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
                    fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
                });

#if DEBUG
    		builder.Logging.AddDebug();
            builder.Services.AddSingleton<MainPageViewModel>();
            builder.Services.AddSingleton<AddItemNewWindowViewModel>();
#endif

            return builder.Build();
        }
        
    }
}
