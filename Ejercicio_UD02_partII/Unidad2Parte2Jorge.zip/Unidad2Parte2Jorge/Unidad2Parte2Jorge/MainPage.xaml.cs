﻿namespace Unidad2Parte2Jorge
{
    public partial class MainPage : ContentPage
    {
        int count = 0;
        int _comprobar;
        int valencianoA;
        int valencianoB;
        int valencianoC;

        int inglesA;
        int inglesB;
        int inglesC;

        int francesA;
        int francesB;
        int francesC;

        public MainPage()
        {
            InitializeComponent();
            BindingContext = this;
            
        }
        private async void verCreditos(object sender, EventArgs e)
        {
            string action = await DisplayActionSheet("Creditos:\n Jorge Quintana González", "Cancell", null);
        }
        private async void InputValenciano(object sender, EventArgs e)
        {
            string action = await DisplayActionSheet("¿Nivel de valenciano?", "Cancell", null, "A", "B", "M");
            if (action.Equals("A"))
            {
                valencianoA++;
            }
            entryValenciano.Text = action;
        }
        public async void InputIngles(object sender, EventArgs e)
        {
            string action = await DisplayActionSheet("¿Nivel de inglés?", "Cancell", null, "A", "B", "M");
            if (action.Equals("A"))
            {
                inglesA++;
            }
            entryIngles.Text = action;
        }
        public async void InputFrances(object sender, EventArgs e)
        {
            string action = await DisplayActionSheet("¿Nivel de francés?", "Cancell", null, "A", "B", "M");
            if (action.Equals("A"))
            {
                francesA++;
            }
            entryFrances.Text = action;
        }
        public int comprobar
        {
            get { return _comprobar; }
            set
            {
                _comprobar = value;
                labelIdiomas.Text = "Idiomas a nivel avanzado =" + value;
                OnPropertyChanged(nameof(comprobar));
            }
        }

        private async void BtnComprobar(object sender, EventArgs e)
        {
            string action = await DisplayActionSheet("¿Quieres ver el número de idiomas avanzados?", "Cancell", null, "SI", "NO");
            if(action.Equals("SI"))
            {
                comprobar = 0;
                comprobar = this.valencianoA + this.inglesA + this.francesA;

            }
            else if(action.Equals("NO"))
            {
                entryValenciano.Text = "";
                entryIngles.Text = "";
                entryFrances.Text = "";
            }
            
            
        }
    }

}
